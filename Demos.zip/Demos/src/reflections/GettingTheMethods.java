package reflections;

public class GettingTheMethods {

	public static void main(String[] args) {

	}

}
