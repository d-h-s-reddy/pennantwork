package reflections;

class Simple {
}

public class GettingInstance {

	public static void main(String[] args) {
		try {
			Class c = Class.forName("reflections.Simple");
			System.out.println(c.getName());

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// getClass
		Simple s = new Simple();
		Class c2 = s.getClass();
		System.out.println(c2.getName());
		// .class
		Class c1 = Simple.class;
		System.out.println(c1.getName());

	}

}
