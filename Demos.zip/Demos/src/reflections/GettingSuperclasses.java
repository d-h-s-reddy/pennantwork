package reflections;

public class GettingSuperclasses {

	public static void main(String[] args) {
		Class cls;
		try {
			cls = Class.forName("java.util.ArrayList");
			while ((cls = cls.getSuperclass()) != null) {
				System.out.println(cls);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
