package multithreading;

public class UsingMethodsOfThreadClass extends Thread {
	public UsingMethodsOfThreadClass(String name) {
		super(name);
	}

	UsingMethodsOfThreadClass a = null;

	public void assinging(UsingMethodsOfThreadClass t) {
		a = t;
	}

	public void run() {
		System.out.println(a.getState());
		System.out.println("hi hello");
		System.out.println(a.getState());

	}

	public static void main(String[] args) {
		UsingMethodsOfThreadClass t = new UsingMethodsOfThreadClass("This is my first thread");
		t.assinging(t);
		System.out.println(t.getName());
		System.out.println(t.getPriority());
		System.out.println(t.getState());
		System.out.println(t.getId());
		t.start();
		System.out.println("HI");
		System.out.println(t.getState());

	}

}
