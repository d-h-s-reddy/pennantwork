package multithreading;

class NewThread implements Runnable {
	public void run() {
		int i = 1;
		while (true) {
			System.out.println(i + "hello");
			i++;
		}

	}
}

public class UsingRunnable {

	public static void main(String[] args) {
		NewThread n = new NewThread();
		Thread t = new Thread(n);
		t.start();
		int i = 1;
		while (true) {
			System.out.println(i + "world");
			i++;
		}

	}

}
