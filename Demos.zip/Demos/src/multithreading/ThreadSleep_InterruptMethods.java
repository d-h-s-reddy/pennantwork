package multithreading;

public class ThreadSleep_InterruptMethods extends Thread {
	public void run() {
		int count = 1;
		while (count < 10) {
			System.out.println(count++);
			try {
				sleep(1000); // because it is a static method we have a chance that we are allowed to write directly and
								// it should be written inside the try catch block because it throws interrupt exception

			} catch (Exception e) {
				System.out.println(e);
			}

		}
	}

	public static void main(String[] args) {
		ThreadSleep_InterruptMethods t = new ThreadSleep_InterruptMethods();
		t.start();
		t.interrupt();
	}

}
