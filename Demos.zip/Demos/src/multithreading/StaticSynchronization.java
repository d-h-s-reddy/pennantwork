package multithreading;

class MT1 extends Thread {
	public synchronized void table(int n) {
		for (int i = 1; i <= 5; i++) {
			System.out.println(i * n);
		}
	}
}

class T1 extends MT1 {
	public void run() {
		table(1);
	}
}

class T2 extends MT1 {
	public void run() {
		table(2);
	}
}

class T3 extends MT1 {
	public void run() {
		table(3);
	}
}

class T4 extends MT1 {
	public void run() {
		table(4);
	}
}

public class StaticSynchronization {

	public static void main(String[] args) {
		T1 t1 = new T1();
		T2 t2 = new T2();
		T3 t3 = new T3();
		T4 t4 = new T4();
		t1.start();
		t2.start();
		t3.start();
		t4.start();

	}

}
