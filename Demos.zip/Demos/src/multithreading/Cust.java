package multithreading;

class ATM {
	synchronized public void checkbalance(String name) {
		System.out.println("Name of the customer is:" + name);
		try {

			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Balance");
	}

	synchronized public void withdraw(String name, int amount) {
		System.out.println("name of the customer:" + name);
		try {

			Thread.sleep(500);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(" Amount that is to be withdraw is:" + amount);
	}

}

public class Cust extends Thread {
	ATM a;
	String name;
	int amount;

	Cust(ATM aa, String name, int amount) {
		a = aa;
		this.name = name;
		this.amount = amount;
	}

	public void run() {
		useAtm();
	}

	public void useAtm() {
		a.checkbalance(name);
		a.withdraw(name, amount);
	}

	public static void main(String[] args) {
		Cust c = new Cust(new ATM(), "HARI", 1000);
		Cust c1 = new Cust(new ATM(), "Sankar", 10000);
		c.start();

		c1.start();
	}

}
