package multithreading;

public class SleepMethods extends Thread {
	public void run() {
		for (int i = 0; i < 100; i++) {
			System.out.println(i);
			try {
				sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		SleepMethods m1 = new SleepMethods();
		SleepMethods m2 = new SleepMethods();
		m1.start();
		m2.start();

	}

}
