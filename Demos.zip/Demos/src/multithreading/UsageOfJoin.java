package multithreading;

public class UsageOfJoin extends Thread {
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println(i + "  " + this);
				sleep(500);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public static void main(String[] args) {
		UsageOfJoin u = new UsageOfJoin();
		UsageOfJoin u1 = new UsageOfJoin();
		UsageOfJoin u2 = new UsageOfJoin();
		u.start();
		try {
			u.join();
		} catch (Exception e) {
			System.out.println(e);
		}
		u1.start();
		u2.start();

	}

}
