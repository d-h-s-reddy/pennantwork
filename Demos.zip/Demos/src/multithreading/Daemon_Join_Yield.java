package multithreading;

public class Daemon_Join_Yield extends Thread {
	public void run() {
		int count = 1;
		while (count < 10) {
			System.out.println(count++);
		}
	}

	public static void main(String[] args) {
		Daemon_Join_Yield d = new Daemon_Join_Yield();
		d.setDaemon(true);
		d.start();
		System.out.println("This is the starting of the new thread");
		try {
			d.sleep(1000);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
