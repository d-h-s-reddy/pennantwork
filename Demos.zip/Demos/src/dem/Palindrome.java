package dem;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int temp = num;
		int reverse = 0;
		while (temp > 0) {
			reverse = (reverse * 10) + (temp % 10);
			temp = temp / 10;
		}
		if (num == reverse) {
			System.out.println("The given number is a palindrome");
		} else {
			System.out.println("The given number is not an palindrome");
		}
	}

}
