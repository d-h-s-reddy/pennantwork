package dem;

import java.util.Scanner;

public class DecimalToBinary {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		String s = "";
		while (num > 0) {
			int r = num % 2;
			s = s + r;
			num = num / 2;
		}
		StringBuilder str = new StringBuilder(s);
		System.out.println(str.reverse());
	}

}
