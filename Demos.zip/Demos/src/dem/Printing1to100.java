package dem;

public class Printing1to100 {

	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) {
			System.out.print(i + "  ");
			if (i % 5 == 0) {
				System.out.println();
			}
		}

	}

}
