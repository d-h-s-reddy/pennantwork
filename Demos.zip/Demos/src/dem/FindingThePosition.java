package dem;

import java.util.Scanner;

public class FindingThePosition {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int flag = 0;
		if (num > 999) {
			System.out.println("BIG");
			flag = 1;
		}
		if (num % 15 == 0) {
			System.out.println("SPECIAL");
		}
		if ((num % 5 == 0 && num % 6 == 0) && (num % 18 != 0)) {
			System.out.println("WIRED");
			flag = 1;
		}
		if (flag == 1) {
			System.out.println("SCARY");
		}
	}
}
