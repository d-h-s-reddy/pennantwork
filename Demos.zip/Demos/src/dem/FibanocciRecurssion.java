package dem;

import java.util.Scanner;

public class FibanocciRecurssion {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int value = fib(num);
		System.out.println(value);
	}

	static int fib(int num) {
		if (num <= 1) {
			return num;
		} else {
			return fib(num - 1) + fib(num - 2);
		}
	}
}
