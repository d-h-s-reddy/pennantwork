package dem;

public class Min_Max_Avg {

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		int c = Integer.parseInt(args[2]);
		int max = 0;
		int min = 0;
		if (a > b && a > c) {
			max = a;
			if (b < c) {
				min = b;
			} else {
				min = c;
			}
		} else if (b > c) {
			max = b;
			if (a < c) {
				min = a;
			} else {
				min = c;
			}
		} else {
			max = c;
			if (a < b) {
				min = a;
			} else {
				min = b;
			}
		}
		System.out.println("The Min number is:" + min);
		System.out.println("The Max number is:" + max);
		System.out.println("The Avg number is:" + (a + b + c) / 3);
	}

}
