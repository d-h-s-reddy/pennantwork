package dem;

public class PrimeAmstrongPalindrome {

	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) {
			prime(i);
			amstrong(i);
			palindrome(i);
		}
	}

	private static void palindrome(int num) {
		int temp = num;
		int reverse = 0;
		while (temp > 0) {
			reverse = (reverse * 10) + (temp % 10);
			temp = temp / 10;
		}
		if (num == reverse) {
			System.out.println("The given number is a palindrome");
		} else {
			System.out.println("The given number is not an palindrome");
		}

	}

	private static void amstrong(int num) {
		int temp = num;
		int reverse = 0;
		while (temp > 0) {
			int r = temp % 10;
			reverse = reverse + r * r * r;
			temp = temp / 10;
		}
		if (num == reverse) {
			System.out.println("Amstrong number");
		} else {
			System.out.println("not an amstrong number");
		}

	}

	private static void prime(int i) {
		int count = 1;
		for (int j = 2; j <= i; j++) {
			if (i % j == 0) {
				count++;
			}
		}
		if (count == 2) {
			System.out.println("prime number");
		} else {
			System.out.println("not a prime number");
		}

	}

}
