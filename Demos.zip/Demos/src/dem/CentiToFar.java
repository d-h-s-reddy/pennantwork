package dem;

import java.util.Scanner;

public class CentiToFar {

	public static void main(String[] args) {
		int centi;
		Scanner sc = new Scanner(System.in);
		centi = sc.nextInt();
		System.out.println((double) (((9 * centi) / 5) + 32));
	}
}
