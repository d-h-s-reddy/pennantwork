package dem;

import java.util.Scanner;

public class PasswordStrength {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		System.out.println("The password is:" + str);
		String s = checking(str);

	}

	static String checking(String pswd) {
		int caps = 0;
		int numerical = 0;
		int special = 0;
		for (int i = 0; i < pswd.length(); i++) {
			if ('A' <= pswd.charAt(i) && pswd.charAt(i) <= 'Z') {
				caps++;
			}
			if ('#' <= pswd.charAt(i) && pswd.charAt(i) <= '/') {
				special++;
			}
			if ('0' <= pswd.charAt(i) && pswd.charAt(i) <= '9') {
				numerical++;
			}
		}
		if (caps >= 1) {
			return "Medium";
		} else if (caps >= 1 && numerical >= 1 && special >= 1) {
			return "Strong";
		} else {
			return "Weak";
		}
	}
}
