package dem;

import java.util.Scanner;

public class FactorialRecurrsion {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int factorial = fact(num);
		System.out.println(factorial);
	}

	static int fact(int num) {
		if (num == 1 || num == 0) {
			return 1;
		} else {
			return num * fact(num - 1);
		}

	}

}
