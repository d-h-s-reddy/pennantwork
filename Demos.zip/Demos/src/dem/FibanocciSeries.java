package dem;

import java.util.Scanner;

public class FibanocciSeries {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int f0 = 0;
		int f1 = 1;
		int f2;
		System.out.print(f0 + " ");
		System.out.print(f1 + " ");
		for (int i = 2; i <= num; i++) {
			f2 = f0 + f1;
			System.out.print(f2 + " ");
			f0 = f1;
			f1 = f2;
		}

	}

}
