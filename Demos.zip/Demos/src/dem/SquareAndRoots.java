package dem;

import java.util.Scanner;

public class SquareAndRoots {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.println("The square of the number is:" + (arr[i] * arr[i]));
			if (arr[i] < 0) {
				System.out.println("For negative numbers square root is not possible");
			} else {
				System.out.println(Math.sqrt(arr[i]));
			}

		}
	}
}
