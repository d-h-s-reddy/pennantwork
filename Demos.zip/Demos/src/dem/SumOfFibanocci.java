package dem;

import java.util.Scanner;

public class SumOfFibanocci {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int f0 = 0;
		int f1 = 1;
		int f2;
		int sum = 1;
		for (int i = 2; i <= num; i++) {
			f2 = f0 + f1;
			sum = sum + f2;
			f0 = f1;
			f1 = f2;
		}
		System.out.println(sum);
	}

}
