package dem;

public class CentiToFarhInRnage {

	public static void main(String[] args) {
		for (int centi = 28; centi <= 50; centi++) {
			System.out.print((double) (((9 * centi) / 5) + 32) + " ");
		}
	}
}
