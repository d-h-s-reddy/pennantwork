package dem;

public class PalindromeRange {

	public static void main(String[] args) {
		for (int num = 100; num <= 200; num++) {
			int temp = num;
			int reverse = 0;
			while (temp > 0) {
				reverse = (reverse * 10) + (temp % 10);
				temp = temp / 10;
			}
			if (num == reverse) {
				System.out.println("The given number" + num + " is a palindrome");
			} else {
				System.out.println("The given number" + num + " is not an palindrome");
			}
		}
	}
}
