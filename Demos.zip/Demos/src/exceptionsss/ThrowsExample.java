package exceptionsss;

public class ThrowsExample {
	static int div(int a, int b) throws ArithmeticException {
		return a / b;
	}

	public static void main(String[] args) {
		try {
			System.out.println(div(10, 0));
		} catch (ArithmeticException e) {
			System.out.println("IT IS IN VALID");
		}
	}

}
