package exceptionsss;

class InAge extends Exception {
	InAge(String str) {
		super(str);
	}
}

public class InvalidUserNumber {

	public static void validation(int age) throws InAge {
		if (age < 18) {
			throw new InAge("Invalid age for voting");
		} else {
			System.out.println("The user is eligible for voting");
		}
	}

	public static void main(String[] args) {
		try {
			validation(13);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
