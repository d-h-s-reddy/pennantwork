package arrays;

import usable.Pre;

public class Difference_Largest_Smallest {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		int max = arr[0];
		int min = arr[0];
		if (arr.length > 1) {
			for (int n : arr) {
				if (n > arr[0]) {
					max = n;
				}
				if (n < min) {
					min = n;
				}
			}
			System.out.println(max - min);
		}

	}

}
