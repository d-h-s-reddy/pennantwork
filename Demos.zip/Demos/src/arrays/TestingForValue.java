package arrays;

import java.util.Scanner;

public class TestingForValue {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.print("Enter the element to test whether it is in the array or not ");
		int value = sc.nextInt();
		boolean flag = false;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == value) {
				flag = true;
				break;
			}
		}
		if (flag == true) {
			System.out.println("The given value is presented in the array");
		} else {
			System.out.println("The given value is not presented in the array");
		}

	}

}
