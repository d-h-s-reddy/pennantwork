package arrays;

import java.util.Scanner;

import usable.Pre;

public class FindSumOfPairs {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		p.printing(arr);
		System.out.println();
		System.out.println("Enter the sum that we want to find:");
		Scanner sc = new Scanner(System.in);
		int sum = sc.nextInt();
		int val = 0;
		System.out.println("The pairs of the data are:");
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				val = arr[i] + arr[j];
				if (sum == val) {
					System.out.println("The pairs are:" + arr[i] + "," + arr[j]);
				}
			}
		}

	}

}
