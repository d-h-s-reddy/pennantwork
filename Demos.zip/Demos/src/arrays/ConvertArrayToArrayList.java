package arrays;

import java.util.ArrayList;
import java.util.Iterator;

import usable.Pre;

public class ConvertArrayToArrayList {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();

		// copying into the array list
		ArrayList<Integer> al = new ArrayList<Integer>();
		for (int i = 0; i < arr.length; i++) {
			al.add(i, arr[i]);
		}

		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.print(itr.next() + " ");
		}

	}
}
