package arrays;

import usable.Pre;

public class ReversingArray {

	public static void main(String[] args) {
		Pre p = new Pre();
		int arr[] = p.array();
		// reversing an array
		int revarray[] = new int[arr.length];
		int j = 0;
		for (int i = arr.length - 1; i >= 0; i--) {
			revarray[j++] = arr[i];
		}
		p.printing(revarray);

	}
}
