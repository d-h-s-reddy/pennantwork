package arrays;

import usable.Pre;

public class CommanElementBetweenAraysInteger {

	public static void main(String[] args) {
		Pre p = new Pre();
		int arr1[] = p.array();
		System.out.println("First array is:");
		p.printing(arr1);
		System.out.println();
		System.out.println("Second array is:");
		int arr2[] = p.array();
		p.printing(arr2);

		// finding the common elements
		boolean flag = false;
		int ele[] = new int[arr1.length];
		for (int i = 0; i < arr1.length; i++) {
			flag = false;
			for (int j = 0; j < arr2.length; j++) {
				if (arr1[i] == arr2[j]) {
					flag = true;
				}
			}
			if (flag == true) {
				System.out.println("The common elements in the two arrays is:" + arr1[i]);
			}
		}
	}
}
