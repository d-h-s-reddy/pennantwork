package arrays;

import usable.Pre;

public class CheckArray {
	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		boolean flag = true;
		for (int n : arr) {
			if (n == 0 || n == -1) {
				flag = false;
				break;
			}
		}
		if (flag == false) {
			System.out.println("The array contain the zero or -1");
		} else {
			System.out.println("The array doesn't contain any zero or -1 values ");
		}
	}
}
