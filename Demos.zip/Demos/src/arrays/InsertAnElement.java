package arrays;

import java.util.Scanner;

public class InsertAnElement {

	static int[] upadtearray(int[] arr, int ele, int index) {
		if (index >= 0 && index <= arr.length) {
			int[] newarray = new int[arr.length + 1];

			// copying the elements before the position
			for (int i = 0; i < index; i++) {
				newarray[i] = arr[i];
			}
			newarray[index] = ele;
			// now copying the remaining values
			for (int i = index + 1; i < newarray.length; i++) {
				newarray[i] = arr[i - 1];
			}
			return newarray;
		} else {
			System.out.println("invalid position");
			return arr;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.print("Enter the element to be inserted:");
		int ele = sc.nextInt();
		System.out.print("Enter the position to be inserted:");
		int index = sc.nextInt();

		int[] uarray = upadtearray(arr, ele, index - 1);
		for (int i = 0; i < arr.length; i++) {
			System.out.println(uarray[i]);
		}

	}

}
