package arrays;

import usable.Pre;

public class ConditionChecking {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		boolean flag = false;
		for (int n : arr) {
			if (n == 65 || n == 77) {
				flag = true;
			}
		}
		if (flag == true) {
			System.out.println("The values are present");
		} else {
			System.out.println("The values are not present");
		}
	}
}
