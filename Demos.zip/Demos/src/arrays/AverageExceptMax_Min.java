package arrays;

import usable.Pre;

public class AverageExceptMax_Min {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		int max = arr[0];
		int min = arr[0];
		if (arr.length > 1) {
			for (int n : arr) {
				if (n > arr[0]) {
					max = n;
				}
				if (n < min) {
					min = n;
				}
			}
		}
		int sum = 0;
		for (int n : arr) {
			if (n == max || n == min) {
				continue;
			} else {
				sum = sum + n;
			}
		}
		System.out.println(sum / (arr.length - 2));
	}
}
