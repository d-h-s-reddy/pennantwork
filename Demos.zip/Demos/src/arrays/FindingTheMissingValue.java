package arrays;

import java.util.Arrays;

import usable.Pre;

public class FindingTheMissingValue {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		Arrays.sort(arr);
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		System.out.println(
				"The missing element in the array is:" + ((arr[arr.length - 1] * (arr[arr.length - 1] + 1)) / 2 - sum));
	}
}
