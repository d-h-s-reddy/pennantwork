package arrays;

import usable.Pre;

public class RemovingDuplicateElements {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		p.printing(arr);

		// finding the duplicates
		int[] dupli = new int[arr.length];
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					arr[j] = 0;
				}
			}
		}
		p.printing(arr);
	}
}
