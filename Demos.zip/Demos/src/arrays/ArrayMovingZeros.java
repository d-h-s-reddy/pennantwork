package arrays;

import usable.Pre;

public class ArrayMovingZeros {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		p.printing(arr);

		int nozeroindex = 0;
		for (int n : arr) {
			if (n != 0) {
				arr[nozeroindex++] = n;
			}
		}
		while (nozeroindex < arr.length) {
			arr[nozeroindex++] = 0;
		}
		System.out.println();
		p.printing(arr);
	}
}
