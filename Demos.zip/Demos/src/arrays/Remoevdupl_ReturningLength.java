package arrays;

import usable.Pre;

public class Remoevdupl_ReturningLength {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();

		int[] dupli = new int[arr.length];
		int count = 0;
		int k = 0;
		for (int n : arr) {
			if (checking(dupli, n)) {
				int val = 0;
				for (int j : arr) {
					if (n == j) {
						val++;
					}
				}
				if (val > 0) {
					dupli[k++] = n;
				}
				count++;
			} else {
				continue;
			}
		}
		System.out.println(count);

	}

	private static boolean checking(int[] dupli, int n) {
		for (int i : dupli) {
			if (i == n) {
				return false;
			}
		}
		return true;
	}

}
