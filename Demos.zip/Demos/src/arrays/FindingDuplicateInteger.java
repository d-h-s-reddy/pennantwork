package arrays;

import usable.Pre;

public class FindingDuplicateInteger {

	public static void main(String[] args) {
		Pre p = new Pre();
		int arr[] = p.array();
		p.printing(arr);

		int[] duplicatearray = new int[arr.length];
		int k = 0;
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			count = 0;
			if (checking(duplicatearray, arr[i])) {
				continue;
			}
			for (int j = i; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
				}
			}
			if (count >= 2) {
				duplicatearray[k++] = arr[i];
				System.out.println("The duplicate value is:" + arr[i]);
			}
		}

	}

	static boolean checking(int[] duplicatearray, int ele) {
		for (int i = 0; i < duplicatearray.length; i++) {
			if (duplicatearray[i] == ele) {
				return true;
			}
		}
		return false;
	}

}
