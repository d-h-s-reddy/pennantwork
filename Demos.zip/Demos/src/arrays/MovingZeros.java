package arrays;

import usable.Pre;

public class MovingZeros {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();

	}

}
