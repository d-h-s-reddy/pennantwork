package arrays;

import usable.Pre;

public class SumOf10s {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		int sum = 0;
		for (int n : arr) {
			if (n == 10) {
				sum = sum + n;
			}
		}
		if (sum == 30) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
	}
}
