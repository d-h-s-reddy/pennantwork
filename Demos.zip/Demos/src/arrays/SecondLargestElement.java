package arrays;

import java.util.Arrays;

import usable.Pre;

public class SecondLargestElement {

	public static void main(String[] args) {
		Pre p = new Pre();
		int arr[] = p.array();
		p.printing(arr);
		System.out.println();
		Arrays.sort(arr);
		System.out.println("Second largest element is:" + arr[arr.length - 2]);
		System.out.println("Second smallest element is:" + arr[1]);

	}
}
