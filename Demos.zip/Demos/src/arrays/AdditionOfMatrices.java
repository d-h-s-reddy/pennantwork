package arrays;

import usable.Twod;

public class AdditionOfMatrices {

	public static void main(String[] args) {
		Twod t = new Twod();
		int[][] arr1 = t.array();
		int[][] arr2 = t.array();
		int[][] sum = new int[arr1.length][arr1[0].length];
		if ((arr1.length == arr2.length) && (arr1[0].length == arr2[0].length)) {
			for (int i = 0; i < arr1.length; i++) {
				for (int j = 0; j < arr1[0].length; j++) {
					sum[i][j] = arr1[i][j] + arr2[i][j];
				}
			}
			t.printing(sum);
		} else {
			System.out.println("The addition of two matrices is not possible");
		}
	}
}
