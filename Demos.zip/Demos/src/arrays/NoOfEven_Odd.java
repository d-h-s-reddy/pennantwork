package arrays;

import usable.Pre;

public class NoOfEven_Odd {

	public static void main(String[] args) {
		Pre p = new Pre();
		int[] arr = p.array();
		int even = 0;
		int odd = 0;
		for (int n : arr) {
			if (n % 2 == 0) {
				even++;
			} else {
				odd++;
			}
		}
		System.out.println("No of even integers are:" + even + " No of odd integers are:" + odd);
	}
}
