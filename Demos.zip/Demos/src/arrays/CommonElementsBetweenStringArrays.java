package arrays;

import usable.Pre;

public class CommonElementsBetweenStringArrays {

	public static void main(String[] args) {
		Pre p = new Pre();
		String[] arr1 = p.sarray();
		System.out.println("The first string array is:");
		p.sprinting(arr1);
		String[] arr2 = p.sarray();
		System.out.println("The second string array is:");
		p.sprinting(arr2);

		boolean flag = false;
		int ele[] = new int[arr1.length];
		for (int i = 0; i < arr1.length; i++) {
			flag = false;
			for (int j = 0; j < arr2.length; j++) {
				if (arr1[i].equals(arr2[j])) {
					flag = true;
				}
			}
			if (flag == true) {
				System.out.println("The common elements in the two arrays is:" + arr1[i]);
			}
		}

	}
}
