package arrays;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import usable.Pre;

public class ArrayListToArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> al = new ArrayList<Integer>();
		System.out.println("Enter the no of elements to enter:");
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			int val = sc.nextInt();
			al.add(val);
		}

		int[] arr = new int[n];
		Iterator itr = al.iterator();
		int i = 0;
		while (itr.hasNext()) {
			arr[i++] = (int) itr.next();
		}

		Pre p = new Pre();
		p.printing(arr);
	}
}
