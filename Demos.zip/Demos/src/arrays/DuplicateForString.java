package arrays;

import usable.Pre;

public class DuplicateForString {

	public static void main(String[] args) {
		Pre p = new Pre();
		String arr[] = p.sarray();
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			count = 0;
			for (int j = i; j < arr.length; j++) {
				if (arr[i].equals(arr[j])) {
					count++;
				}
			}
			if (count >= 2) {
				System.out.println("The string that is duplicate is:" + arr[i]);
			}
		}

	}

}
