package inheritance;

public class TrainTicket {
	int TicketNo;
	int TrainNo;
	int TravelDate;
	String source;
	String Destination;
	String name;
	int age;
	String Gender;

	void displayTicketDetails() {
		System.out.println(TicketNo + " " + TrainNo + " " + TravelDate + " " + source + " " + Destination + " " + name
				+ " " + age + " " + Gender);
	}

	TrainTicket(int tino, int tno, int tdate, String s, String dest, String name, int age, String g) {
		TicketNo = tino;
		TrainNo = tno;
		TravelDate = tdate;
		source = s;
		Destination = dest;
		this.name = name;
		this.age = age;
		Gender = g;
	}

	float calculateFinalFare(double basefare) {
		if (age < 5) {
			return 0.0f;
		} else if (5 <= age && age <= 12) {
			return (float) (basefare / 2);
		} else if ((Gender == "M" && age > 65) || (Gender == "F" && age > 58)) {
			return (float) (basefare - (basefare * 25) / 100);
		} else {
			return (float) basefare;
		}
	}

	public static void main(String[] args) {
		TrainTicket t = new TrainTicket(1, 10, 1213, "Vizag", "Rjy", "HARI", 20, "M");
		System.out.println(t.calculateFinalFare(200));

	}
}
