package inheritance;

class A {
	int a = 10;
	int b = 20;
	int d;

	void display() {
		System.out.println(a + " " + b);
	}
}

public class Single_Multi extends A {
	int c = 30;

	void dis() {
		display();
		System.out.println(c);
	}

	public static void main(String[] args) {
		Single_Multi s = new Single_Multi();
		s.dis();

	}

}
