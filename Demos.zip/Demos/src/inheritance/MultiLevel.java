package inheritance;

class A1 {
	int a = 10;
	static int b;

	// A1(int a, int b) {
	// this.a = a;
	// this.b = b;
	// } it is an error
	A1() {
		System.out.println("This is class A1");
	}

	void dis() {
		System.out.println("a");
	}

	static void displaying() {
		System.out.println("This is static of a");
	}
}

class B extends A1 {
	int a;
	int c;
	int d;

	B() {
		System.out.println(super.a);
		c = 10;
		d = 20;
		super.b = 100;
		System.out.println(a + " " + b + " " + c + " " + d);
		System.out.println("This is class B");
		super.displaying();
		super.a = 50;

	}

	void dis() {
		System.out.println("b");
	}

	static void displaying() {
		System.out.println("This is static method of b");
	}
}

public class MultiLevel extends B {
	MultiLevel() {
		super();
		super.c = 100;
		super.dis();

	}

	static void displaying() {
		System.out.println("This is static method of c");
	}

	public static void main(String[] args) {
		MultiLevel mul = new MultiLevel();
		mul.displaying();
		B.displaying();

	}

}
