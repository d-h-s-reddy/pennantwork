package inheritance;

public class Employee {
	int empno;
	String name;
	String job;
	double salary;

	Employee(int empno, String name, String job, double salary) {
		this.empno = empno;
		this.name = name;
		this.job = job;
		this.salary = salary;
	}

	Employee(int empno, double salary) {
		this.empno = empno;
		this.salary = salary;
	}

	Employee(int empno, String name, double salary) {
		this.empno = empno;
		this.name = name;
		this.salary = salary;
	}

	void displayProfile() {
		System.out.println(empno + " " + name + " " + job + " " + salary);
	}

	double calMonthlyPayroll(int nod, int attend, int noh) {
		int nol = nod - noh - attend;
		int nopd = nod - nol;
		double payroll = (salary / 30) * nopd;
		return payroll;
	}

	public static void main(String[] args) {
		Employee e = new Employee(14, "hari", "ase", 12000.00);
		System.out.println(e.calMonthlyPayroll(30, 240, 30));
	}
}
