package inheritance;

class Degree {
	void getDegree() {
		System.out.println("I got a degree");
	}
}

class Undergraduate extends Degree {
	void getDegree() {
		System.out.println("I am an Undergraduate");
	}
}

class Postgraduate extends Degree {
	void getDegree() {
		System.out.println("I am an Postgraduate");
	}
}

public class Dem {

	public static void main(String[] args) {
		Postgraduate p = new Postgraduate();
		Undergraduate u = new Undergraduate();
		Degree d = new Degree();
		d.getDegree();
		u.getDegree();
		p.getDegree();
	}

}
