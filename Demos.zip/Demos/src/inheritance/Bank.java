package inheritance;

abstract class Loan {
	int AccountNo;
	String AccountTitle;
	String Address;
	String LoanType;
	String LoanRemarks;
	double LoanAmount;
	int NoOfInstallments;
	int InstallmentsPaid;
	double TotalToBePaid;
	double TotalPaid;
	String Nominee;
	int LoanTerm;
	String StartDate;
	static int RateOfInt;

	public Loan(int i, String string, String string2, String string3, String string4, int j, int k, int l, int m, int n,
			String string5, int o, String string6, int p) {
		AccountNo = i;
		AccountTitle = string;
		Address = string2;
		LoanType = string3;
		LoanRemarks = string4;
		LoanAmount = j;
		NoOfInstallments = k;
		InstallmentsPaid = l;
		TotalToBePaid = m;
		TotalPaid = n;
		Nominee = string5;
		LoanTerm = o;
		StartDate = string6;
		RateOfInt = p;

	}

	void PayEmi(double amt) {
		TotalPaid = TotalPaid + amt;
	}

	double calEmi() {
		return (LoanAmount * RateOfInt * Math.pow((1 + RateOfInt), NoOfInstallments)
				/ ((Math.pow((1 + RateOfInt), NoOfInstallments)) - 1));
	}

	abstract double CalTotalToBePaid();
}

class GoldLoan extends Loan {

	public GoldLoan(int i, String string, String string2, String string3, String string4, int j, int k, int l, int m,
			int n, String string5, int o, String string6, int p) {
		super(i, string, string2, string3, string4, j, k, l, m, n, string5, o, string6, p);
		// TODO Auto-generated constructor stub
	}

	@Override
	double CalTotalToBePaid() {
		System.out.println("It is the total amount to be paid for the Goldloan");
		return LoanAmount + (LoanAmount * RateOfInt * NoOfInstallments) / 100;
	}

}

class VehicleLoan extends Loan {

	public VehicleLoan(int i, String string, String string2, String string3, String string4, int j, int k, int l, int m,
			int n, String string5, int o, String string6, int p) {
		super(i, string, string2, string3, string4, j, k, l, m, n, string5, o, string6, p);
		// TODO Auto-generated constructor stub
	}

	@Override
	double CalTotalToBePaid() {
		System.out.println("It is the total amount to be paid for the Vehicleloan");
		return LoanAmount + (LoanAmount * RateOfInt * NoOfInstallments) / 100;
	}

}

class MortguageLoan extends Loan {

	public MortguageLoan(int i, String string, String string2, String string3, String string4, int j, int k, int l,
			int m, int n, String string5, int o, String string6, int p) {
		super(i, string, string2, string3, string4, j, k, l, m, n, string5, o, string6, p);
	}

	@Override
	double CalTotalToBePaid() {
		System.out.println("It is the total amount to be paid for the Mortguage loan");
		return LoanAmount + (LoanAmount * RateOfInt * NoOfInstallments) / 100;
	}

}

class EMICalculator {
	static void GenerateEMI(Loan ln, double prnpleamt, double rateofint, int term) {

	}
}

class TotalToPayCalculator {
	static void CalTotalToPay(Loan ln, double prnpleamt, int term) {

	}
}

public class Bank {

	static void display(Loan l) {
		if (l instanceof GoldLoan) {
			GoldLoan g = (GoldLoan) l;
			g.CalTotalToBePaid();
		}
		if (l instanceof VehicleLoan) {
			VehicleLoan g = (VehicleLoan) l;
			g.CalTotalToBePaid();
		}
		if (l instanceof MortguageLoan) {
			MortguageLoan g = (MortguageLoan) l;
			g.CalTotalToBePaid();
		}
	}

	public static void main(String[] args) {
		MortguageLoan m = new MortguageLoan(1, "Savings", "Rjy", "Mortaguage", "No", 100000, 10, 5, 120000, 100000,
				"hari", 5, "12-12-2002", 5);
		EMICalculator e = new EMICalculator();
		Bank b = new Bank();
		e.GenerateEMI(m, 0, 0, 0);

	}

}
