package inheritance;

public class DemoOperation {

	public static void main(String[] args) {
		int x, y, z;
		x = y = z = 200;
		x = y++ + z-- + ++y;
		y = --z + x++ - z--;
		z = x-- + y-- + --x;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);

	}

}
