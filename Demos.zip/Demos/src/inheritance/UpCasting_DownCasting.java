package inheritance;

class Account {
	int bal = 10000;

	public void deposit(int amt) {
		bal = bal + amt;
	}

	public void withdraw(int money) {
		if (bal >= money) {
			bal = bal - money;
		} else {
			System.out.println("Insufficient funds");
		}
	}

	public void display() {
		System.out.println("account");
	}
}

class SavingsAccount extends Account {
	public void display() {
		System.out.println("This is an savings account");
	}

}

class CurrentAccount extends Account {
	public void withdraw(int money) {
		if (bal >= money) {
			bal = bal - money;
			if (bal <= 10000) {
				bal = bal + money;
				System.out.println("Insufficient funds");
			}
		} else {
			System.out.println("Insufficient funds");
		}
	}

	public void display() {
		System.out.println("This is an current account");
	}

}

public class UpCasting_DownCasting {
	static void dis(Account a) {
		a.display();
		if (a instanceof SavingsAccount) {
			SavingsAccount sa = (SavingsAccount) a;
			sa.display();
		}
		if (a instanceof CurrentAccount) {
			CurrentAccount ca = (CurrentAccount) a;
			ca.display();
		}
	}

	public static void main(String[] args) {
		SavingsAccount sa = new SavingsAccount();
		CurrentAccount ca = new CurrentAccount();
		/*
		 * Account a = null; a = sa;// upcasting CurrentAccount ca1 = (CurrentAccount) a;//downcasting
		 */
		dis(sa);
		dis(ca);

	}

}
