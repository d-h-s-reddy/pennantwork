package inheritance;

import java.util.Scanner;

class Member {
	String name;
	int age;
	long phno;
	String address;
	double salary;

	Member(Scanner sc) {
		name = sc.nextLine();
		age = sc.nextInt();
		phno = sc.nextLong();
		sc.nextLine();
		address = sc.nextLine();
		salary = sc.nextDouble();
		sc.nextLine();
	}

	void printSalary() {
		System.out.println("The salary of the member:" + name + " is:" + salary);
	}
}

class Emp extends Member {
	String specialization;
	String department;

	Emp(Scanner sc) {
		super(sc);
		specialization = sc.nextLine();
		department = sc.nextLine();
	}

}

class Manager extends Member {

	String specialization;
	String department;

	Manager(Scanner sc) {
		super(sc);
		specialization = sc.nextLine();
		department = sc.nextLine();
	}

}

public class Printingdata {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the details of the Employee");
		Emp e = new Emp(sc);
		e.printSalary();
		Manager m = new Manager(sc);
		m.printSalary();

	}

}
