package examples;

class Account {
	double balance;

	Account(double balance) {
		this.balance = balance;
	}

	// void deposit(double amt) {
	// balance += amt;
	// System.out.println(balance);
	// }

	double withdraw(double amt) {
		balance -= amt;
		System.out.println(balance);
		return balance;
	}
}

class SavingsAccount extends Account {

	SavingsAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}

	double withdraw(double amt) {
		balance -= amt;
		return balance;
	}

}

class CurrentAccount extends Account {

	CurrentAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}

	double withdraw(double amt) {
		balance -= amt;
		return balance;
	}

}

class RecurringAccount extends Account {

	RecurringAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}

	double withdraw(double amt) {
		balance -= amt;
		return balance;
	}

}

class Demo {
	void doTransactioin(Account a) {
		if (a instanceof SavingsAccount) {
			SavingsAccount sa = (SavingsAccount) a;
			sa.withdraw(10000);
		}
		if (a instanceof CurrentAccount) {
			CurrentAccount ca = (CurrentAccount) a;
			ca.withdraw(10000);
		}
		if (a instanceof RecurringAccount) {
			RecurringAccount ra = (RecurringAccount) a;
			ra.withdraw(100000);
		}
	}
}

public class BankTransaction {

	public static void main(String[] args) {
		// Demo d = new Demo();
		// SavingsAccount sa = new SavingsAccount(100000);
		// d.doTransactioin(sa);

		// Account a = new Account(100000);
		// a.deposit(50000);
		// Account a2 = a;
		// a2.withdraw(75000);
		// System.out.println(a.balance);

	}

}
