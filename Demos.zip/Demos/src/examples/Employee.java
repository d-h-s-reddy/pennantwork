package examples;

public class Employee {
	int empno;
	String name;
	String designation;
	double basicSalary;
	double ctc;
	double monthlypay;

	Employee(int e, String name, String desig, double basicsal, double ctc) {
		empno = e;
		this.name = name;
		designation = desig;
		basicSalary = basicsal;
		this.ctc = ctc;
	}

	double calculateMonthlyPay(String month, int atnd) {
		int noofdays;
		if (month.equals("Jan") || month.equals("march") || month.equals("may") || month.equals("july")
				|| month.equals("august") || month.equals("october") || month.equals("december")) {
			noofdays = 31;
		} else if (month.equals("feb")) {
			noofdays = 29;
		} else {
			noofdays = 30;
		}
		monthlypay = basicSalary + (15 * basicSalary / 100) * (atnd / noofdays)
				+ (12 * basicSalary / 100) * (atnd / noofdays) + (9 * basicSalary / 100) * (atnd / noofdays)
				- calculateTax(ctc);
		return monthlypay;
	}

	void displayDetails() {
		System.out.println("The details of the employee is: " + empno + " name:" + name + " designation:" + designation
				+ " basicSalary:" + basicSalary);
		System.out.println("pay slip take homesalary" + monthlypay);
	}

	static double calculateTax(double ctc) {
		if (ctc < 300000) {
			return 0.0;
		} else if (300000 < ctc && ctc < 500000) {
			return ctc * 10 / 100;
		} else if (500000 < ctc && ctc < 1000000) {
			return ctc * 20 / 100;
		} else {
			return ctc * 30 / 100;
		}
	}

	public static void main(String[] args) {
		Employee e = new Employee(1, "hari", "ase", 12000, 410000);
		e.calculateMonthlyPay("Jan", 31);
		e.displayDetails();

	}

}
