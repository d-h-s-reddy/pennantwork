package mom;

import java.util.Scanner;

public class Shoppingcart extends Thread {
	Shopper sc;
	int oid;

	public Shoppingcart(Shopper s) {
		sc = s;
	}

	Scanner s = new Scanner(System.in);

	public void run() {
		while (true) {
			System.out.println("Enter the order id:");
			sc.enqueue(s.nextInt());
			System.out.println("Order added susccessfully ");
		}

	}

}
