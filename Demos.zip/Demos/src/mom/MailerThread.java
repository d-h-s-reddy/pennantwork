package mom;

public class MailerThread extends Thread {
	Shopper sc;

	MailerThread(Shopper s) {
		sc = s;
	}

	public void run() {
		if (!sc.q.isEmpty()) {
			System.out.println();
			System.out.println("Message sent through the mail");
			sc.dequeue(0);
			System.out.println();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		} else {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
