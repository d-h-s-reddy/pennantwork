package mom;

public class WhatsappThread extends Thread {
	Shopper sc;

	WhatsappThread(Shopper s) {
		sc = s;
	}

	public void run() {
		if (!sc.q.isEmpty()) {
			System.out.println();
			System.out.println("Message sent through the whatsapp");
			sc.dequeue(1);
			System.out.println();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		} else {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
