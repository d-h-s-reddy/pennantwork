package mom;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class Shopper {
	Queue<Order> q = new LinkedList<>();

	public void enqueue(int oid) {
		q.add(new Order(oid));
	}

	public void dequeue(int num) {
		Order o;
		if (num == 0) {
			o = q.peek();
		} else {
			o = q.remove();
		}
		System.out.println("Order id: " + o.oid + " Total Price on the order: " + o.totalprice);
		Iterator itr2 = (o.li).iterator();
		while (itr2.hasNext()) {
			Item i = (Item) itr2.next();
			System.out.println("Item id: " + i.id + " Item name: " + i.name + " Item Price: " + i.price
					+ " Item Qunatity: " + i.quantity + " Item Tax: " + i.tax);
		}
	}
}
