package mom;

import java.util.Scanner;

public class dems {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		Shopper s = new Shopper();
		Shoppingcart sh = new Shoppingcart(s);
		Customer c = new Customer(s);
		sh.start();
		c.start();
	}

}
