package mom;

public class Customer extends Thread {
	Shopper sc;

	Customer(Shopper s) {
		sc = s;
	}

	public void run() {

		while (true) {
			MailerThread mt = new MailerThread(sc);
			mt.start();
			try {
				mt.join();
			} catch (Exception e) {
			}
			WhatsappThread wt = new WhatsappThread(sc);
			wt.start();
		}
	}
}
