package mom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Order {
	int oid;
	double totalprice;
	ArrayList<Item> li = new ArrayList<>();
	Random r = new Random();

	Order(int oid) {
		this.oid = oid;
		for (int i = 0; i < 4; i++) {
			li.add(new Item((i + 1), "soap", r.nextFloat(100.00f, 1000.00f), r.nextInt(10), r.nextInt(15)));
		}
		// total amount
		Iterator itr = li.iterator();
		while (itr.hasNext()) {
			Item i = (Item) itr.next();
			totalprice += i.price;
		}
	}

}
