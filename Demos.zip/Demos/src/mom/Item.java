package mom;

public class Item {
	int id;
	String name;
	double price;
	int quantity;
	int tax;

	public Item(int id, String name, double price, int quantity, int tax) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.tax = tax;
	}

}
