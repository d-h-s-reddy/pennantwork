package abstraction;

interface A {
	void display();
}

interface B {
	void display();
}

public class MultipleInheritance implements A, B {
	public void display() {
		System.out.println("The multiple inheritance is working");
	}

	public static void main(String[] args) {
		MultipleInheritance m = new MultipleInheritance();
		m.display();
	}
}
