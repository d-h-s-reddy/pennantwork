package abstraction;

abstract class shape {
	private String color;

	public abstract double area();

	public abstract String display();

	public shape(String color) {
		this.color = color;
	}

	public String getcolor() {
		return color;
	}
}

class Circle extends shape {
	double radius;

	Circle(double r, String color) {
		super(color);
		radius = r;
	}

	public double area() {
		return 3.14 * radius * radius;
	}

	public String display() {
		return "The color of the circle is:" + super.getcolor() + " The area is:" + area();
	}

}

class Rectangle extends shape {
	double length;
	double width;

	Rectangle(double length, double width, String color) {
		super(color);
		this.length = length;
		this.width = width;
	}

	public double area() {
		return length * width;
	}

	public String display() {
		return "The color of the Rectangle is:" + super.getcolor() + " The area is:" + area();
	}
}

public class UsingAbstractClass {

	public static void main(String[] args) {
		Circle c = new Circle(4, "skyblue");
		Rectangle re = new Rectangle(3, 4, "Royal Blue");
		System.out.println(c.display());
		System.out.println(re.display());

	}

}
