package abstraction;

interface shape1 {
	void display();
}

class Rectangle1 implements shape1 {
	public void display() {
		System.out.println("This is the Rectangle class");
	}
}

class Circle1 implements shape1 {
	public void display() {
		System.out.println("This is circle class");
	}
}

public class UsageOfInterfaces {
	public void dis(shape1 s) {
		if (s instanceof Rectangle1) {
			Rectangle1 r = (Rectangle1) s;
			r.display();
		} else {
			Circle1 c = (Circle1) s;
			c.display();
		}
	}

	public static void main(String[] args) {
		Circle1 c = new Circle1();
		UsageOfInterfaces s = new UsageOfInterfaces();
		s.dis(c);
		Rectangle1 r = new Rectangle1();
		s.dis(r);

	}

}
