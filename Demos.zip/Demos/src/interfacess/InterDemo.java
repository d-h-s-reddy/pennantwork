package interfacess;

interface printable {
	void print(int a, int b);
}

public class InterDemo implements printable {
	public void print(int b, int a) {
		System.out.println("hello" + a + b);
	}

	public static void main(String[] args) {
		InterDemo i = new InterDemo();
		i.print(10, 20);

	}

}
