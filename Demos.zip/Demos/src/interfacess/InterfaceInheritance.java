package interfacess;

interface inter1 {
	void m1();

	void m2();
}

interface inter2 extends inter1 {
	void m3();

	void m4();
}

class A implements inter1 {

	@Override
	public void m1() {
		System.out.println("m1");

	}

	@Override
	public void m2() {
		System.out.println("m2");
	}

}

class B implements inter2 {

	@Override
	public void m1() {
		System.out.println("m1 of 2");
	}

	@Override
	public void m2() {
		System.out.println("m2 of 2");
	}

	@Override
	public void m3() {
		System.out.println("m3");
	}

	@Override
	public void m4() {
		System.out.println("m4");
	}

}

public class InterfaceInheritance {

	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		inter1 i1 = null;
		inter2 i2 = null;
		i1 = a;
		i1 = b;
		// i2 =a; it is not possible because we cannt assign the
		i2 = b;
		i2.m3();

	}

}
