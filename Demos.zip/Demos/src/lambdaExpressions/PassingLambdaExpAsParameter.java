package lambdaExpressions;

class Uselambda {
	public void use(Mylambda ml) {
		ml.display();
	}
}

public class PassingLambdaExpAsParameter {
	Uselambda u = new Uselambda();

	public void method1() {
		u.use(() -> {
			System.out.println("hello reddy");
		});
	}

	public static void main(String[] args) {
		PassingLambdaExpAsParameter p = new PassingLambdaExpAsParameter();
		p.method1();
	}

}
