package lambdaExpressions;

interface Methodref {
	public void display(String str);
}

public class MethodReferences {
	MethodReferences() {
	};

	MethodReferences(String str) {
		System.out.println(str.toUpperCase());
	}

	public void display2(String str) {
		System.out.println(str + "reddy");
	}

	public static void display1(String str) {
		System.out.println(str + 9244);
	}

	public static void main(String[] args) {
		// for making the display as the constructor
		Methodref ml = MethodReferences::new;
		ml.display("hari");
		// for instance methods
		MethodReferences m = new MethodReferences();
		Methodref m1 = m::display2;
		m1.display("hari");
		// for static methods
		m1 = MethodReferences::display1;
		m1.display("hari");

	}

}
