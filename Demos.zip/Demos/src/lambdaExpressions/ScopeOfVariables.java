package lambdaExpressions;

public class ScopeOfVariables {
	int temp = 10;

	public void method1() {
		int count = 0;
		Mylambda ml = () -> {
			System.out.println(count);
			System.out.println(temp);
			System.out.println(temp++);
		};
		ml.display();
		// count++; if we increment inside the loop it is not possible
	}

	public static void main(String[] args) {
		ScopeOfVariables s = new ScopeOfVariables();
		s.method1();

	}

}
