package lambdaExpressions;

interface Mylambda {
	public void display();
}

interface Myparams {
	public int add(int a, int b);
}

public class DemoClass {

	public static void main(String[] args) {
		Mylambda m = () -> {
			System.out.println("hello world");
		};
		m.display();

		Myparams m1 = (a, b) -> a + b;
		int add = m1.add(10, 20);
		System.out.println(add);
	}

}
