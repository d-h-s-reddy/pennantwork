package innerclasses;

public class StaticClasses {
	static class Sinner {
		static int a = 10;

		static void display() {
			System.out.println("Hello world");
		}
	}

	public static void main(String[] args) {
		StaticClasses.Sinner o = new StaticClasses.Sinner();
		o.display();

	}

}
