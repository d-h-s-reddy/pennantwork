package innerclasses;

interface Transcation {
	void deposit(double amt);

	void withdraw(double amt);
}

public class AduitAccount {
	int balance = 10000;

	public void auditTransaction() {
		try {
			Transcation t = new Transcation() {

				@Override
				public void deposit(double amt) {
					balance += amt;

				};

				@Override
				public void withdraw(double amt) {
					if (balance < amt) {
						System.out.println("Infussicient balance");
					} else {
						balance -= amt;
					}
				};
			};
			t.deposit(1000);
			t.withdraw(100);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void display() {
		System.out.println(balance);
	}

	public static void main(String[] args) {
		AduitAccount t = new AduitAccount();
		t.auditTransaction();
		t.display();

	}

}
