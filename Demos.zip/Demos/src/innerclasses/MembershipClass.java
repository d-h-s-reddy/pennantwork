package innerclasses;

public class MembershipClass {
	public void display() {
		System.out.println("This is the outer class");
	}

	class Inner1 {
		public void display() {
			System.out.println("This is the inner class 1");
		}
	}

	protected class Inner2 {
		public void display() {
			System.out.println("This is the inner class 2 ");
		}

		class Inner3 {
			public void display() {
				System.out.println("This is the inner class 3");
			}
		}
	}

	public static void main(String[] args) {
		MembershipClass m = new MembershipClass();
		MembershipClass.Inner1 i1 = m.new Inner1();
		i1.display();
		MembershipClass.Inner2 i2 = m.new Inner2();
		i2.display();
		Inner2.Inner3 i3 = i2.new Inner3();
		i3.display();

	}

}
