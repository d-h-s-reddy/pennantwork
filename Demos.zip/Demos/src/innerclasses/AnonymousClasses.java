package innerclasses;

abstract class Test {
	abstract void display();
}

public class AnonymousClasses {

	public static void main(String[] args) {
		Test t = new Test() {
			void display() {
				System.out.println("hello");
			}
		};
		t.display();

		AnonymousClasses a = new AnonymousClasses() {
			public void dis() {
				System.out.println("this is instance method");
			}
		};

		// a.dis(); it can't be called

	}
}
