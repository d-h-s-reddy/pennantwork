package innerclasses;

public class LocalInnerClass {
	public void display() {
		int a = 50;
		int val = 100;
		class Inner {
			int a = 30;
			int b = 40;

			public void dis() {
				System.out.println(a);
				System.out.println(val);// we can use the variables outside the class
			}
		}
		Inner i = new Inner();
		i.dis();
		System.out.println(i.b);
	}

	public static void main(String[] args) {
		LocalInnerClass l = new LocalInnerClass();
		l.display();

	}

}
