package praticeno1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

class Item {
	int id;
	String name;
	double price;
	int quantity;
	int tax;

	public Item(int id, String name, double price, int quantity, int tax) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.tax = tax;
	}

}

class Order {
	int oid;
	double totalprice;
	ArrayList<Item> li = new ArrayList<>();
	Random r = new Random();

	Order(int oid) {
		this.oid = oid;
		for (int i = 0; i < 4; i++) {
			li.add(new Item((i + 1), "soap", r.nextFloat(100.00f, 1000.00f), r.nextInt(10), r.nextInt(15)));
		}
		// total amount
		Iterator itr = li.iterator();
		while (itr.hasNext()) {
			Item i = (Item) itr.next();
			totalprice += i.price;
		}
	}

}

class Shopper {
	Queue<Order> q = new LinkedList<>();

	public void enqueue(int oid) {
		q.add(new Order(oid));
	}

	public void dequeue(int num) {

		Order o;
		if (num == 0) {
			o = q.peek();
		} else {
			o = q.remove();
		}
		System.out.println("Order id: " + o.oid + " Total Price on the order: " + o.totalprice);
		Iterator itr2 = (o.li).iterator();
		while (itr2.hasNext()) {
			Item i = (Item) itr2.next();
			System.out.println("Item id: " + i.id + " Item name: " + i.name + " Item Price: " + i.price
					+ " Item Qunatity: " + i.quantity + " Item Tax: " + i.tax);
		}
	}
}

class Shoppingcart extends Thread {
	Shopper sc;
	int oid;

	Shoppingcart(Shopper s, int oid) {
		this.oid = oid;
		sc = s;
	}

	public void run() {
		synchronized (this) {
			sc.enqueue(oid);
			System.out.println("Order added Successfully");
			notifyAll();
		}

	}
}

class MailerThread extends Thread {
	Shopper sc;

	MailerThread(Shopper s) {
		sc = s;
	}

	public void run() {
		synchronized (sc) {
			while (sc.q.size() == 0) {
				try {
					sc.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			System.out.println();
			System.out.println("Mail msg:You order is successfully placed");
			sc.dequeue(0);
			System.out.println();

		}

	}
}

class WhatsappThread extends Thread {
	Shopper sc;

	WhatsappThread(Shopper s) {
		sc = s;
	}

	public void run() {

		synchronized (sc) {
			while (sc.q.size() == 0) {
				try {
					sc.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println();
			System.out.println("Whatsapp msg:You order is successfully placed");
			sc.dequeue(1);
			System.out.println();

		}

	}
}

public class Demo {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		Shopper s = new Shopper();
		Thread t;
		while (true) {
			System.out.print("Enter the order id");
			int a = sc.nextInt();
			t = new Thread(new Shoppingcart(s, a));
			t.start();
			// t.join();
			t = new Thread(new MailerThread(s));
			t.start();
			// t.join();
			t = new Thread(new WhatsappThread(s));
			t.start();
		}
	}
}
