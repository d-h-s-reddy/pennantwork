package generics;

public class GenericMethods {

	public <T> void display(T[] element) {
		for (T ele : element) {
			System.out.println(ele);
		} // here there is no need to declare every time the data type that we want to convert
	}

	public static void main(String[] args) {
		GenericMethods g = new GenericMethods();
		Integer[] a1 = { 10, 20, 30, 40, 50 };
		Character[] c1 = { 'a', 'b', 'c' };
		g.display(a1);
		g.display(c1);

	}

}
