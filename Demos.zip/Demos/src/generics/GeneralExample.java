package generics;

class Demo<T> {
	T obj;

	Demo(T o) {
		obj = o;
	}

	public T display() {
		System.out.println("This is the display method");
		return obj;
	}
}

public class GeneralExample {

	public static void main(String[] args) {
		Demo<Integer> d1 = new Demo<>(10);
		Demo<String> d2 = new Demo<>("Hello world");
		System.out.println(d1.display());
		System.out.println(d2.display());

	}

}
