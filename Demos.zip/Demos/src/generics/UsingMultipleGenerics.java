package generics;

class Demo1<T, U> {
	T obj1;
	U obj2;

	public void display(T obj1, U obj2) {
		this.obj1 = obj1;
		this.obj2 = obj2;
		System.out.println(obj1);
		System.out.println(obj2);
	}

}

public class UsingMultipleGenerics {
	public static void main(String[] args) {
		Demo1<String, Integer> d = new Demo1<>();
		d.display("hari", 10);
	}
}
