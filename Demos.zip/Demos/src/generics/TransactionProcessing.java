package generics;

public class TransactionProcessing<T extends Account> {
	T obj;

	TransactionProcessing(T o) {
		obj = o;
	}

	public void calling() {
		obj.withdraw(1000);
	}

	public static void main(String[] args) {
		SavingsAccount sa = new SavingsAccount(101, "NK", 50000, true);
		CurrentAccount ca = new CurrentAccount(102, "NS", 20000, 500000);
		Account a = new Account(103, "ss", 10000);
		TransactionProcessing<SavingsAccount> tp1 = new TransactionProcessing<>(sa);
		TransactionProcessing<CurrentAccount> tp2 = new TransactionProcessing<>(ca);
		TransactionProcessing<Account> tp3 = new TransactionProcessing<>(a);
		tp1.calling();
		tp2.calling();
		tp3.calling();

	}

}
