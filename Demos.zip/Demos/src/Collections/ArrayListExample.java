package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(10);
		al.add(20);
		al.add(500);
		al.add(40);
		al.add(100);
		// for(int e:al) {
		// System.out.println(e);
		// } using the iterable interface

		// using the iterator interface
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
