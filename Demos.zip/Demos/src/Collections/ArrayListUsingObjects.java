package Collections;

import java.util.ArrayList;
import java.util.Iterator;

class Student {
	int id;
	String name;
	int marks;

	Student(int id, String name, int marks) {
		this.id = id;
		this.name = name;
		this.marks = marks;
	}
}

public class ArrayListUsingObjects {

	public static void main(String[] args) {
		Student s1 = new Student(1, "A", 100);
		Student s2 = new Student(1, "b", 100);
		Student s3 = new Student(1, "c", 100);
		Student s4 = new Student(1, "d", 100);
		ArrayList<Student> al = new ArrayList<>();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			Student s = (Student) itr.next();
			System.out.println(s.id + s.name + s.marks);
		}

	}

}
