package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Student1 implements Comparator<Student1> {
	int id;
	String name;
	int marks;

	Student1(int id, String name, int marks) {
		this.id = id;
		this.name = name;
		this.marks = marks;
	}

	@Override
	public int compare(Student1 o1, Student1 o2) {
		System.out.println(o1.id);
		System.out.println(o2.id);
		System.out.println();

		return o1.id - o2.id;
	}

}

public class SortingInCollections {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		al.add(10);
		al.add(30);
		al.add(0);
		System.out.println("ArrayList before sorting:" + al);
		Collections.sort(al);
		System.out.println("ArrayList after sorting:" + al);
		Student1 s1 = new Student1(1, "A", 100);
		Student1 s2 = new Student1(2, "B", 200);
		Student1 s3 = new Student1(3, "C", 100);
		ArrayList<Student1> ss = new ArrayList<>();
		ss.add(s3);
		ss.add(s1);
		ss.add(s2);
		Collections.sort(ss, s1);
		Iterator itr = ss.iterator();
		while (itr.hasNext()) {
			Student1 s = (Student1) itr.next();
			System.out.println(s.id);
		}

	}

}
