package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;

class StudentDe {
	int regNo;
	String fullName;
	Date dob;
	String branch;
	float cgpa;
	short yearofpass;

	public StudentDe(int regNo, String fullName, Date dob, String branch, float cgpa, short yearofpass) {
		this.regNo = regNo;
		this.fullName = fullName;
		this.dob = dob;
		this.branch = branch;
		this.cgpa = cgpa;
		this.yearofpass = yearofpass;
	}

	public void display() {
		System.out.println("Regno:" + regNo + " Full name:" + fullName + " Date:" + dob + " Branch:" + branch + " CGPA:"
				+ cgpa + " YearofPassing:" + yearofpass);
	}
}

class MyTeam {
	List<StudentDe> team = new ArrayList<>();
	Random r = new Random();

	public MyTeam() {
		for (int i = 0; i < 10; i++) {
			team.add(new StudentDe(i + 1, "A", new Date(), "It", r.nextFloat(0.00f, 10.00f), (short) 24));
		}
	}

	public void sortAndPrintByDOB() {
		Collections.sort(team, new Comparator<StudentDe>() {

			@Override
			public int compare(StudentDe o1, StudentDe o2) {
				return o1.dob.compareTo(o2.dob);
			}
		});
		Iterator l = team.iterator();
		while (l.hasNext()) {
			StudentDe s = (StudentDe) l.next();
			s.display();
		}
	}

	public void sortAndPrintByCGPA() {
		Collections.sort(team, new Comparator<StudentDe>() {

			@Override
			public int compare(StudentDe o1, StudentDe o2) {
				return (int) (o1.cgpa - o2.cgpa);
			}
		});
		Iterator l = team.iterator();
		while (l.hasNext()) {
			StudentDe s = (StudentDe) l.next();
			s.display();
		}

	}
}

class MyBatch {
	Random r = new Random();
	HashMap<StudentDe, HashMap<Integer, Float>> data = new HashMap<>();
	HashMap<Integer, Float> innermap = new HashMap<>();

	public MyBatch(List<StudentDe> team) {
		for (int i = 0; i < team.size(); i++) {
			for (int j = 0; j < 4; j++) {
				innermap.put(j + 1, r.nextFloat(0.0f, 10.0f));
			}
			data.put(team.get(i), innermap);
		}
	}

	public void displaySemWiseMarks() {
		for (Map.Entry<StudentDe, HashMap<Integer, Float>> entry : data.entrySet()) {
			StudentDe s = (StudentDe) entry.getKey();
			s.display();
			for (Map.Entry<Integer, Float> endetails : entry.getValue().entrySet()) {
				System.out.println(endetails.getKey() + " " + endetails.getValue());
			}
		}
	}
}

class GameScore {
	String gameName;
	int score;

	public GameScore(String gameName, int score) {
		this.gameName = gameName;
		this.score = score;
	}
}

class MyGame extends MyTeam {
	Queue<GameScore> gamescores = new LinkedList<>();

	void setScore(GameScore gscore) {
		gamescores.offer(gscore);
	}

	public GameScore getScore() {
		return gamescores.poll();
	}
}

public class Demo {

	public static void main(String[] args) {
		MyTeam t = new MyTeam();
		MyBatch b = new MyBatch(t.team);
		b.displaySemWiseMarks();

	}

}
