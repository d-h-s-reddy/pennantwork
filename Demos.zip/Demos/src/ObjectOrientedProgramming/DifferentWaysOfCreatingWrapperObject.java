package ObjectOrientedProgramming;

public class DifferentWaysOfCreatingWrapperObject {

	@SuppressWarnings("removal")
	public static void main(String[] args) {
		// 1) general method the wrapper class constructor
		Integer a = new Integer(10);
		Integer b = new Integer(10);
		System.out.println(a == b);

		// 2) using the valueOf() method
		Integer a1 = Integer.valueOf(10);
		Integer b1 = Integer.valueOf(10);
		System.out.println(a1 == b1);

		// 3)using the AutoBoxing method it is same as valueOf() but a small change is the compiler do it automatically
		Integer a3 = 5;
		Integer b3 = 5;
		System.out.println(a3 == b3);
	}
}
