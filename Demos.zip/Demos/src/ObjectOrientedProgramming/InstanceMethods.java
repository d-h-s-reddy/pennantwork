package ObjectOrientedProgramming;

public class InstanceMethods {

	int rollno;
	String name;
	int marks;

	InstanceMethods() {
	}

	InstanceMethods(int rollno, String name, int marks) {
		this.rollno = rollno;
		this.name = name;
		this.marks = marks;
	}

	public void display(int rollno, String name, int marks) {
		System.out.println(rollno + name + marks);
		System.out.println("This is an instance block");
	}

	public static void main(String[] args) {
		InstanceMethods i = new InstanceMethods();
		i.display(i.rollno = 14, i.name = "hari", i.marks = 100);
		InstanceMethods i1 = new InstanceMethods(100, "xyz", 200);
		i1.display(i1.rollno, i1.name, i1.marks);

	}
}
