package ObjectOrientedProgramming;

public class UsageOfValueOf {

	public static void main(String[] args) {
		// valueOf() converts the String to Integer object
		int a = 10;
		String s = String.valueOf(a);
		String s1 = "hello" + s;
		System.out.println(s1);
		Integer i = Integer.valueOf(s);
		System.out.println(i);

		// parseInt() Converts the String object to primitive integer
		String b = "20";
		Integer b1 = Integer.parseInt(b);
		System.out.println(b1);

		// toString(); converts the any objects type to string it doesn't has any parameters
		Integer c = new Integer(90);
		String c1 = c.toString();
		System.out.println(c + " " + c1);

	}

}
