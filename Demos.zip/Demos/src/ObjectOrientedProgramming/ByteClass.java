package ObjectOrientedProgramming;

public class ByteClass {

	public static void main(String[] args) {
		Byte b = new Byte((byte) 55);
		System.out.println(b);
		Byte b1 = Byte.valueOf((byte) 10);
		System.out.println("The floating point value of the byte is:" + b.floatValue());

		Boolean bo = Boolean.valueOf("hari");
		System.out.println(bo);
		Boolean bo1 = bo.booleanValue();
		System.out.println(bo1);

	}

}
