package ObjectOrientedProgramming;

public class Staticblock {
	int a;
	static int b;

	public void display() {
		System.out.println("This is an instance block");
	}

	public static void display1() {
		System.out.println("This is an static block");
	}

	static {
		System.out.println();
		System.out.println(b);// it prints the value zero because the static block is executed first then the main
								// method is executed
		// System.out.println(a); we cann't use the instance variables inside the static block
		display1();
		// display(); instance methods cann't be called

	}

	public static void main(String[] args) {
		Staticblock s = new Staticblock();
		s.a = 10;
		s.b = 100;

	}
}
