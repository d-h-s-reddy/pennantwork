package ObjectOrientedProgramming;

public class StaticVariablesAndMethods {

	static int a;// static variable
	int b; // instance variable so we can have different value to different instance

	static void display() {
		System.out.println(a);
		// System.out.println(b); because it is not a static variable we cann't use it in the static method
		System.out.println("hello world");

	}

	static void display(int a) {
		System.out.print("hi " + a);
	}

	public static void main(String[] args) {
		StaticVariablesAndMethods s = new StaticVariablesAndMethods();
		s.a = 10;
		s.display();
		s.b = 20;
		System.out.println(s.b);
		StaticVariablesAndMethods s1 = new StaticVariablesAndMethods();
		s1.display();
		s1.b = 30;
		System.out.println(s1.b);
		display(20);

	}

}
