package ObjectOrientedProgramming;

public class AutoBoxingAndUnboxing {

	public static void main(String[] args) {
		// autoboxig: primitive to object
		int a = 10;
		Integer a1 = a;
		System.out.println(a1);

		// unboxing: object to primitive
		Integer a2 = 10;
		int a3 = a2;
		System.out.println(a3);
	}

}
