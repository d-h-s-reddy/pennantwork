package ObjectOrientedProgramming;

public class CreationofObjects {
	int a;
	int b;

	public static void main(String[] args) {
		CreationofObjects c = new CreationofObjects();
		c.a = 10;
		c.b = 20;
		System.out.println(c.a);
		System.out.println(c.b);

	}

}
