package ObjectOrientedProgramming;

public class Constructors {

	int rollno;
	String name;
	int marks;

	Constructors(int rollno, String name) {
		this.rollno = rollno;
		this.name = name;
	}

	public static void main(String[] args) {
		// default constructor
		// Constructors c = new Constructors();
		// System.out.println(c.rollno + c.name + c.marks);

		// parameterized constructor
		Constructors c1 = new Constructors(14, "Hari");
		System.out.println(c1.rollno + c1.name + c1.marks);

	}

}
