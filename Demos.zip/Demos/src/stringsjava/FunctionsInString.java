package stringsjava;

public class FunctionsInString {

	public static void main(String[] args) {
		// string literals
		String s1 = "hari";
		String s2 = "Reddy";
		String s3 = "hari";
		// String creation using the new keyword
		String s4 = new String("hari");
		String s5 = new String("hari");

		// comparing
		System.out.println(s1 == s2); // false
		System.out.println(s1 == s3); // true
		System.out.println(s3 == s5); // false
		System.out.println(s1 == s4); // false
		System.out.println(s1.equals(s2));// false
		s3 = s1 + s2;
		System.out.println(s3);// hariReddy
		char[] s6 = s1.toCharArray();// ['h','a','r','i']
		for (char i : s6) {
			System.out.println(i);
		}

	}

}
