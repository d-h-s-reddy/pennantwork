package stringsjava;

public class StringBufferClass {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("hello world");
		sb.append(" The data part");
		sb.toString();
		System.out.println(sb);
		sb.reverse();
		// sb = sb + "h"; it is not possible
	}
}
