package stringsjava;

public class Upper {

	public static void main(String[] args) {
		String s = "hello how are you";
		String k = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ' ' || i == 0) {
				k = k + " ";
				k = k + (s.charAt(i + 1) + "").toUpperCase();
				i++;
			} else {
				k = k + s.charAt(i);
			}

		}
		System.out.println(k);

	}

}
