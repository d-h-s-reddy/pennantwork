package files;

import java.io.FileWriter;

public class Writer {

	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("D:\\notes\\4.txt");
			String str = "This is file writer";
			fw.write(str);
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
