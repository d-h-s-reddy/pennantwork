package files;

public class ConsoleClass {

	public static void main(String[] args) {
		System.out.println("Enter the password:");
		char[] pass = System.console().readPassword();
		System.out.println(pass.toString());
	}

}
