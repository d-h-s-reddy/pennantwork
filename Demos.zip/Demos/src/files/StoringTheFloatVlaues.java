package files;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class StoringTheFloatVlaues {

	public static void main(String[] args) throws Exception {
		// FileOutputStream fos = new FileOutputStream("D:\\notes\\floats.txt");
		// DataOutputStream dos = new DataOutputStream(fos);
		// float li[] = { 10.0f, 11.1f, 12.98f };
		// dos.writeInt(li.length);
		// for (float l : li) {
		// dos.writeFloat(l);
		// }
		// dos.close();
		// fos.close();

		// retriving out
		FileInputStream fis = new FileInputStream("D:\\notes\\floats.txt");
		DataInputStream dis = new DataInputStream(fis);
		int len = dis.readInt();
		for (int i = 0; i < len; i++) {
			System.out.println(dis.readFloat());
		}

	}

}
