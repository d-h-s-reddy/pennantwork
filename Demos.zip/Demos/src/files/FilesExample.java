package files;

import java.io.File;

public class FilesExample {

	public static void main(String[] args) throws Exception {
		File f = new File("D:\\notes");
		System.out.println(f.isDirectory());
		String list[] = f.list();
		for (String s : list) {
			System.out.println(s);
		}
		// we can also get the list of files in the file array
		File li[] = f.listFiles();
		for (File l : li) {
			System.out.println(l.getName());
		}
	}

}
