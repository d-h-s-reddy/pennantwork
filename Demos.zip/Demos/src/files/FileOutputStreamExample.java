package files;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamExample {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos = new FileOutputStream("D:\\notes\\1.txt");
		// adding an integer into the file
		fos.write(65);
		// adding the strings
		String str = "\n This is my first file programming";
		byte[] b = str.getBytes();
		fos.write(b);
		System.out.println("Success");
		fos.close();
	}

}
