package files;

import java.io.FileInputStream;
import java.io.IOException;

public class FIS {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("D:\\notes\\1.txt");
		int i = 0;
		System.out.println("It will print the no of charaters in the file" + fis.available());
		while ((i = fis.read()) != -1) {
			System.out.print((char) i);
		}
		fis.close();

	}

}
