package files;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class Dis {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("D:\\notes\\3.txt");
		DataInputStream dis = new DataInputStream(fis);
		System.out.println(dis.readInt());
		dis.close();
		fis.close();

	}
}
