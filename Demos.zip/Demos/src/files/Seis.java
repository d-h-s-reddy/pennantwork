package files;

import java.io.FileInputStream;
import java.io.SequenceInputStream;

public class Seis {

	public static void main(String[] args) throws Exception {
		FileInputStream f1 = new FileInputStream("D:\\notes\\1.txt");
		FileInputStream f2 = new FileInputStream("D:\\notes\\2.txt");
		SequenceInputStream s = new SequenceInputStream(f1, f2);
		int i;
		while ((i = s.read()) != -1) {
			System.out.print((char) i);
		}
		s.close();
		f1.close();
		f2.close();

	}

}
