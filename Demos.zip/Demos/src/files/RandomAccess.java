package files;

import java.io.RandomAccessFile;

public class RandomAccess {

	public static void main(String[] args) throws Exception {
		RandomAccessFile rf = new RandomAccessFile("D:\\notes\\Demo.txt", "rw");
		// byte[] b = new byte[1024];
		// rf.read(b);
		// String s = new String(b);
		System.out.println((char) rf.read());
		System.out.println((char) rf.read());
		System.out.println((char) rf.read());
		// now the pointer is in D
		// so change the letter
		rf.write('d');
		rf.skipBytes(3);
		System.out.println((char) rf.read());
		rf.seek(3);
		System.out.println(rf.getFilePointer());

		rf.close();
	}

}
