package files;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Dos {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos = new FileOutputStream("D:\\notes\\3.txt");
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeInt(65);
		dos.close();
		fos.close();
	}

}
