package files;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Bos {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos = new FileOutputStream("D:\\notes\\2.txt");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		String str = new String(
				"hi hello namesta asgdajhsgdjhasgdfjhagskdaghsdhgahsdgahsdasgdahsdbkashdajhsdjkashdkhauswjdhajkshdbjkashckhagshdcascbasjcga,jshgcajshcgjashgchajsbcja vsjhcgajhksgcjashgcbjhgscjahgsc,jahschasjdcgajhscgajhgscjhghgcjsjhcgajhsjhdgajh");
		byte[] b = str.getBytes();
		bos.write(b);
		bos.close();
		fos.close();

	}

}
