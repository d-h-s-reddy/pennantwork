package files;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;

public class PipedExamples {

	public static void main(String[] args) throws Exception {
		final PipedReader pr = new PipedReader();
		final PipedWriter pw = new PipedWriter(pr);
		Thread t = new Thread(new Runnable() {
			public void run() {
				int i;
				try {
					i = pr.read();
					while (i != -1) {
						System.out.println((char) i);
						i = pr.read();
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		Thread t1 = new Thread(new Runnable() {
			public void run() {

				try {
					pw.write("i am");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		t.start();
		t1.start();
		pr.close();
		pw.close();

	}

}
