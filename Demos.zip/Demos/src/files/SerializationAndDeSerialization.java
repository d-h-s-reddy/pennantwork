package files;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student1 implements Serializable {
	int id;
	String name;
	String dept;
	static String clg = "jntu";
	transient int marks;

	Student1(int id, String name, String dept) {
		this.id = id;
		this.name = name;
		this.dept = dept;
		marks = 100;
	}

	Student1() {
	}

	public String toString() {
		return "id:" + id + "name:" + name + "dept:" + dept + "clg:" + clg + "marks:" + marks;
	}
}

public class SerializationAndDeSerialization {

	public static void main(String[] args) throws Exception {
		FileOutputStream fos = new FileOutputStream("D:\\notes\\ser.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		Student1 s = new Student1(14, "Hari", "it");
		Student1 s1 = new Student1(15, "a", "It");
		oos.writeObject(s);
		oos.writeObject(s1);
		oos.close();
		fos.close();

		FileInputStream fis = new FileInputStream("D:\\notes\\ser.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Student1 s2;
		try {
			while ((s2 = (Student1) ois.readObject()) != null) {
				System.out.println(s2);
			}
		} catch (Exception e) {
			System.out.println("end of file");
		}

	}

}
