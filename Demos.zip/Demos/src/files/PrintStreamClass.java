package files;

import java.io.FileOutputStream;
import java.io.PrintStream;

class Student {
	int id;
	String name;
	String dept;
}

public class PrintStreamClass {

	public static void main(String[] args) throws Exception {

		FileOutputStream fos = new FileOutputStream("D:\\notes\\5.txt");
		PrintStream ps = new PrintStream(fos);
		Student s = new Student();
		s.id = 10;
		s.name = "hari";
		s.dept = "It";
		ps.println(s.id);
		ps.println(s.name);
		ps.println(s.dept);
		ps.close();
		fos.close();

	}

}
