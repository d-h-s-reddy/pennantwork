package com.relations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootormRelationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootormRelationsApplication.class, args);
	}

}
