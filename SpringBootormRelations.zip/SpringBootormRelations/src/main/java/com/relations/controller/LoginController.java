package com.relations.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.relations.service.LoginService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

	@Autowired
	LoginService ls;

	@GetMapping(value = "/")
	public String entrypage() {
		return "login";
	}

	@PostMapping(value = "/verify")
	public String verify(@RequestParam String username, @RequestParam String password, HttpServletRequest request) {
		if (ls.verifylogin(username)) {
			HttpSession session = request.getSession();
			session.setAttribute("usrname", username);
			return "elearning";
		} else {
			return "error";
		}
	}

	@GetMapping(value = "/getusername")
	@ResponseBody
	public ResponseEntity<String> getusername(HttpSession session) {
		String username = (String) session.getAttribute("usrname");
		if (username != null) {
			return ResponseEntity.ok(username);
		} else {
			return ResponseEntity.status(404).body("please sign in");
		}
	}

}
