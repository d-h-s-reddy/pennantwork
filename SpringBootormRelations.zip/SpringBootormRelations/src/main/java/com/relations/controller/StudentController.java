package com.relations.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.relations.model.Student;
import com.relations.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	StudentService ss;

	@GetMapping(value = "/addstudent")
	@ResponseBody
	public ResponseEntity<String> addstudents(@RequestParam String sname) {
		Student s1 = new Student();
		s1.setStudent_name(sname);
		try {
			ss.savingstudent(s1);
			return ResponseEntity.ok("Student registration has been successfully added to database");
		} catch (RuntimeException e) {
			return ResponseEntity.status(404).body(e.getMessage());
		}
	}

}
