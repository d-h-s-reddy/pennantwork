package com.relations.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.relations.model.Course;
import com.relations.service.CourseService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class CourseController {

	@Autowired
	CourseService cs;

	@GetMapping(value = "/addcourse")
	@ResponseBody
	public ResponseEntity<String> addcourses(@RequestParam String cname) {
		Course c1 = new Course();
		c1.setCourse_name(cname);
		try {
			cs.savingcourses(c1);
			return ResponseEntity.ok("Course has been successfully added to database");
		} catch (RuntimeException e) {
			return ResponseEntity.status(404).body(e.getMessage());
		}
	}

	@GetMapping(value = "/getcourses")
	@ResponseBody
	public ResponseEntity<List<Course>> getemployee() {
		List<Course> courses = cs.findAll();
		if (courses != null) {
			return new ResponseEntity<>(courses, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

	}

	@PostMapping(value = "/addingcoursetosession")
	@ResponseBody
	public ResponseEntity<String> addsession(@RequestBody Course c, HttpServletRequest req) {
		HttpSession session = req.getSession();
		List<Course> cou = (List<Course>) session.getAttribute("courses");
		cou.add(c);
		session.setAttribute("courses", cou);
		return ResponseEntity.ok("added to cart");

	}
}
