package com.relations.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.relations.model.Login;
import com.relations.repository.LoginRepository;

@Service
public class LoginService {

	@Autowired
	LoginRepository lp;

	public boolean verifylogin(String username) {
		Optional<Login> l = lp.findById(username);
		return l.isPresent();
	}

}
