package com.relations.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.relations.model.Course;
import com.relations.repository.CourseRepository;

@Service
public class CourseService {

	@Autowired
	CourseRepository cr;

	public void savingcourses(Course c) {
		Course cs = cr.save(c);
		if (cs == null) {
			throw new RuntimeException("student data is not saved");
		}
	}

	public List<Course> findAll() {
		return cr.findAll();
	}

}
