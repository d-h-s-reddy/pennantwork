package com.relations.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.relations.model.Student;
import com.relations.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository sr;

	public void savingstudent(Student s1) {
		Student ss = sr.save(s1);
		if (ss == null) {
			throw new RuntimeException("course data is not saved");
		}

	}

}
