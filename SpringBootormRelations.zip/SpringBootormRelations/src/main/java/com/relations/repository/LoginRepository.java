package com.relations.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.relations.model.Login;

public interface LoginRepository extends JpaRepository<Login, String> {

}
