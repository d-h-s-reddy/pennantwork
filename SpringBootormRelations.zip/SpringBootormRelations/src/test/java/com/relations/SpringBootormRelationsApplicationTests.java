package com.relations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootormRelationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
